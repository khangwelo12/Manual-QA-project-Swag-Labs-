# Web Workflow Package

## Task
Reconstruct the website's pages, features, workflow, business rules, and page relationships from this package. Do not describe screenshots one by one. Analyze the steps, page URLs, targets, overlays, and notes in steps.json as a complete workflow.

## Capture
- Name: chrome swag labs wwork flow
- Started: 10/27/2026, 18:13:57
- Finished: 10/27/2026, 18:14:58
- Steps: 36
- Unique screenshots: 22
- Steps reusing a screenshot: 14

## Files
- workflow.html: the complete visual workflow in chronological order.
- steps.json: structured action data; steps with the same view reference one screenshot.
- screenshots/: deduplicated page screenshots, with each unique image stored once.

## Analysis requirements
1. Map the information architecture and page hierarchy first.
2. Reconstruct end-to-end workflows by use case.
3. Identify buttons, fields, menus, dialogs, state changes, and navigation.
4. Separate facts visible in the evidence from inferences.
5. List missing, conflicting, or uncertain information separately.
