# Web Workflow Package

## Task
Reconstruct the website's pages, features, workflow, business rules, and page relationships from this package. Do not describe screenshots one by one. Analyze the steps, page URLs, targets, overlays, and notes in steps.json as a complete workflow.

## Capture
- Name: chrome  complete work flow
- Started: 10/27/2026, 16:59:46
- Finished: 10/27/2026, 17:00:28
- Steps: 24
- Unique screenshots: 15
- Steps reusing a screenshot: 9

## Files
- workflow.html: the complete visual workflow in chronological order.
- steps.json: structured action data; steps with the same view reference one screenshot.
- screenshots/: deduplicated page screenshots, with each unique image stored once.

## Analysis requirements
1. Map the information architecture and page hierarchy first.
2. Reconstruct end-to-end workflows by use case.
3. Identify buttons, fields, menus, dialogs, state changes, and navigation.
4. Separate facts visible in the evidence from inferences.
5. List missing, conflicting, or uncertain information separately.
